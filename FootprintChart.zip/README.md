
# NinjaTrader Footprint Chart

This repository contains the NinjaTrader footprint chart code for advanced market order visualization and analysis.

## Repository Structure

```
FootprintChart/
├── NinjaTrader/
│   └── Order_Scan.cs      # NinjaTrader strategy for footprint charts
├── README.md              # Project documentation
└── LICENSE                # License information
```

## Features

- **Footprint Charting**: Visualizes order flow and market footprint data.
- **Market Analysis**: Supports advanced technical analysis using NinjaTrader.

## Setup

### Prerequisites

1. Install NinjaTrader 8 or higher.
2. Import the `Order_Scan.cs` file into NinjaTrader as a custom strategy.

### Usage

1. Open NinjaTrader.
2. Navigate to the strategy manager.
3. Import and apply the `Order_Scan` strategy to your charts.

## License

This project is licensed under the MIT License. See the LICENSE file for details.

---

### Contact

For questions or support, please contact [Your Name/Email].
