
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading;
using System.Net.Sockets;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq; // Include Newtonsoft.Json.Linq for JObject handling
using NinjaTrader.Cbi;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using System.Windows.Threading; // For Dispatcher handling
#endregion

namespace NinjaTrader.NinjaScript.Strategies
{
    public class OCR_PLUS1 : Strategy
    {
        private double internalProfitGoal;
        private double internalLossThreshold;
        private bool internalIsLiveTrading;
        private string internalPatternMode;
        private CancellationTokenSource cancellationTokenSource;
        private bool internalIsTradeOpen = false;

        [NinjaScriptProperty]
        [Display(Name = "Profit Goal", Order = 1, GroupName = "Parameters")]
        public double ConfiguredProfitGoal { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Loss Threshold", Order = 2, GroupName = "Parameters")]
        public double ConfiguredLossThreshold { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use Trailing Stop", Order = 3, GroupName = "Parameters")]
        public bool UseTrailingStop { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Trailing Stop", Order = 4, GroupName = "Parameters")]
        public double ConfiguredTrailingStop { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Number of Orders Per Trade", Order = 5, GroupName = "Parameters")]
        public int OrdersPerTrade { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Connection Code", Order = 6, GroupName = "Parameters")]
        public int ConfiguredConnectionCode { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Enter the description for your new custom Strategy here.";
                Name = "VolumetricOCRPLUS";
                Calculate = Calculate.OnEachTick;
                IsInstantiatedOnEachOptimizationIteration = false;
                internalProfitGoal = 1000; // Default profit goal
                internalLossThreshold = 500; // Default loss threshold
                internalPatternMode = "both"; // Default to both buying and selling patterns

                OrdersPerTrade = 1; // Default to 1 order per trade
                ConfiguredConnectionCode =11176; // Default connection code
            }
            else if (State == State.Configure)
            {
                AddDataSeries(Data.BarsPeriodType.Tick, 1); // Configure your data series
            }
            else if (State == State.DataLoaded)
            {
                StartInternalListenerAsync();
            }
            else if (State == State.Terminated)
            {
                StopInternalListener();
            }
        }

        protected override void OnBarUpdate()
        {
            if (BarsInProgress != 0 || cancellationTokenSource == null || cancellationTokenSource.Token.IsCancellationRequested)
                return;

            try
            {
                double currentProfit = SystemPerformance.AllTrades.TradesPerformance.Currency.CumProfit;

                if (currentProfit >= internalProfitGoal)
                {
                    Print("Profit goal reached. Stopping strategy.");
                    DisableStrategy();
                }
                else if (currentProfit <= -internalLossThreshold)
                {
                    Print("Loss threshold reached. Stopping strategy.");
                    DisableStrategy();
                }

                // Check if trade is closed
                if (internalIsTradeOpen && Position.MarketPosition == MarketPosition.Flat)
                {
                    internalIsTradeOpen = false;
                }
            }
            catch (Exception ex)
            {
                Print("Error in OnBarUpdate: " + ex.Message);
                DisableStrategy();
            }
        }

        public async Task StartInternalListenerAsync()
        {
            cancellationTokenSource = new CancellationTokenSource();
            CancellationToken ct = cancellationTokenSource.Token;

            await Task.Run(async () =>
            {
                try
                {
                    TcpListener listener = new TcpListener(System.Net.IPAddress.Any, ConfiguredConnectionCode);
                    listener.Start();
                    Print("Listening for pattern signals on port " + ConfiguredConnectionCode + "...");

                    while (!ct.IsCancellationRequested)
                    {
                        try
                        {
                            using (TcpClient client = await listener.AcceptTcpClientAsync().ConfigureAwait(false))
                            using (NetworkStream stream = client.GetStream())
                            {
                                byte[] buffer = new byte[1024];
                                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length, ct).ConfigureAwait(false);
                                if (bytesRead > 0)
                                {
                                    string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                                    JObject jsonData = JObject.Parse(message);
                                    int[] patterns = jsonData["Patterns"].ToObject<int[]>();
                                    string dominantColor = jsonData["DominantColor"].ToString();

                                    // Use Dispatcher.Invoke to ensure thread safety when interacting with NinjaTrader objects
                                    Dispatcher.Invoke(() =>
                                    {
                                        HandlePatternReceived(patterns, dominantColor);
                                    });
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Print("Error receiving pattern signal: " + ex.Message);
                        }
                    }

                    listener.Stop();
                    Print("Stopped listening for pattern signals.");
                }
                catch (Exception ex)
                {
                    Print("Error in StartInternalListenerAsync: " + ex.Message);
                }
            }, ct);
        }

        private void StopInternalListener()
        {
            if (cancellationTokenSource != null)
            {
                cancellationTokenSource.Cancel();
                cancellationTokenSource.Dispose();
                cancellationTokenSource = null;
            }
        }

        public void HandlePatternReceived(int[] patterns, string dominantColor)
        {
            if (internalIsTradeOpen)
            {
                Print("A trade is already open. Waiting for it to close before taking new trades.");
                return;
            }

            try
            {
                Print("Received patterns: " + string.Join(",", patterns));
                Print("Dominant Color: " + dominantColor);

                foreach (int pattern in patterns)
                {
                    if (dominantColor == "Buying" && (internalPatternMode == "buy" || internalPatternMode == "both"))
                    {
                        Print("Attempting to enter long position for pattern: " + pattern);
                        EnterLong(OrdersPerTrade, "Pattern" + pattern);
                        SetProfitTarget(CalculationMode.Ticks, ConfiguredProfitGoal);
                        SetStopLoss(CalculationMode.Ticks, ConfiguredLossThreshold);

                        if (UseTrailingStop)
                        {
                            SetTrailStop(CalculationMode.Ticks, ConfiguredTrailingStop);
                        }

                        internalIsTradeOpen = true;
                    }
                    else if (dominantColor == "Selling" && (internalPatternMode == "sell" || internalPatternMode == "both"))
                    {
                        Print("Attempting to enter short position for pattern: " + pattern);
                        EnterShort(OrdersPerTrade, "Pattern" + pattern);
                        SetProfitTarget(CalculationMode.Ticks, ConfiguredProfitGoal);
                        SetStopLoss(CalculationMode.Ticks, ConfiguredLossThreshold);

                        if (UseTrailingStop)
                        {
                            SetTrailStop(CalculationMode.Ticks, ConfiguredTrailingStop);
                        }

                        internalIsTradeOpen = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Print("Error in HandlePatternReceived: " + ex.Message);
            }
        }

        private void DisableStrategy()
        {
            Print("Disabling strategy...");
            StopInternalListener();
            // Add any other cleanup code here
        }
    }
}


